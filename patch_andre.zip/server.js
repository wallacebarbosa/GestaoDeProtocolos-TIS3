var http = require("http");
var fileManager = require("./filemanager");
var config = require("./config");
var database = require("./database");
var parse = require("url").parse;
var queryParse = require('querystring').parse;

var rootFolder = config.rootFolder;
var defaultIndex = config.defaultIndex;
var types = config.types;

var server = http.createServer();



module.exports = server;

server.on('request', OnRequest);

function GetSetorByID(id) {
    for(let i = 0; i < Setor.length; i++)
    {
        if(Setor[i].id == id) {
            return Setor[i];
        }
    }

    return null;
}

function GetUnidadeByID(id) {
    for(let i = 0; i < Unidade.length; i++)
    {
        if(Unidade[i].id == id) {
            return Unidade[i];
        }
    }

    return null;
}

function WriteNormalHead(res, length)
{
    res.writeHead(200, {
        'Content-Type': "text/plain",
        'Content-Length': length
     });
}




function OnRequest(req, res)
{
    // parse path request
    var filename = parse(req.url).pathname;
    var fullPath;
    var extension;

    // if request is root file
    if(filename == '/') {
        filename = defaultIndex;
    }

    console.debug(GetSetorByID(1).nome);

    // if request is ajax
    if(req.method == 'POST') {
        console.debug("POST REQUEST!");

        let body = '';
        req.on('data', chunk => {body += chunk.toString();});
        req.on('end', function() {
            console.debug(body);
            console.debug(filename);

            switch(filename)
            {
                case "/ajax/login":
                    console.debug("Login request!");
                    let quered = queryParse(body);

                    let user = quered.username;
                    let pass = quered.password;

                    ob = '';

                    if(user == "admin" && pass == "123456") {
                        ob = '1';
                        res.writeHead(200, {
                            'Content-Type': "text/plain",
                            'Location': "protocolos.html",
                            'Content-Length': ob.length
                         });
                        res.end(ob);
                    }
                    else
                    {
                        ob = '0';
                        WriteNormalHead(res, ob.length);
                        res.end(ob);
                    }
                    break;
                
                case "/ajax/protocolos":
                    let data = []
                    for(let i = 0; i < Protocolo.length; i++)
                    {
                        data.push(Protocolo[i]);
                    }

                    ob = JSON.stringify(data);
                    WriteNormalHead(res, ob.length);
                    res.end(ob);
                    break;
                
                case "/ajax/setores":
                    let data = []
                    for(let i = 0; i < Setor.length; i++)
                    {
                        data.push(Setor[i]);
                    }

                    ob = JSON.stringify(data);
                    WriteNormalHead(res, ob.length);
                    res.end(ob);
                    break;
                
                case "/ajax/unidades":
                    let data = []
                    for(let i = 0; i < Unidade.length; i++)
                    {
                        data.push(Unidade[i]);
                    }

                    ob = JSON.stringify(data);
                    WriteNormalHead(res, ob.length);
                    res.end(ob);
                    break;

                case "/ajax/cadastro/protocolo":
                    console.debug("Request Cadastro.");
                    data = JSON.parse(body);

                    let destSetor = 0;
                    for(let i = 0; i < Setor.length; i++) {
                        if(Setor[i].nome == data.nome) {
                            destSetor = i;
                        }
                    }

                    let protocol = {
                        "id": Protocolo.length + 1,
                        "titulo": data.titulo,
                        "dataCriacao": 1570661981, // timestamp
                        "owner_id": 1,
                        "descricao": data.descricao
                    }

                    let rota = {
                        "id": 1,
                        "protocolo_id": protocol.id,
                        "remetente_id": 1,
                        "destinatario_id": destSetor,
                        "tipo": "criado",
                        "data":  1570661981, // timestamp
                    }

                    Protocolo.push(protocol);
                    Encaminhamento.push(rota);

                    ob = '1';
                    WriteNormalHead(res, ob.length);
                    res.end(ob);
                    break;
                    
            }
        });

        return;
    }


    // send file data
    fullPath = rootFolder + filename;
    extension = filename.substr(filename.lastIndexOf('.') + 1);

    fileManager(fullPath, function(data) {
        res.writeHead(200, {
           'Content-Type': types[extension] || 'text/plain',
           'Content-Length': data.length
        });
        res.end(data);

    }, function(err) {
        res.writeHead(404);
        res.end('Recurso não encontrado');
    });
    
}