<!-- Footer -->
<footer class="page-footer font-small blue pt-4 col-12 float-left" style="background-color: #76b82a">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2018 Copyright:
    <a href="https://mdbootstrap.com/education/bootstrap/" style="color: white;"> Tis lll</a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->

</body>

</html>