<?php

function LoadModules()
{
    include_once("classes\database.php");
    include_once("classes\user.php");
    include_once("classes\protocolo.php");
}

LoadModules();
?>