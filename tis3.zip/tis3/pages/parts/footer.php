<!-- footer -->
<div id="footer">
            <address>
                <a class="logo" href="#" target="_blank">
                    <img alt="hospital" src="img/pp.jpg">
                </a> <em>copyright ©</em> <a href="#" target="_blank">Puc Minas.</a> <em>By André, Wallace e Lucas - </em><span>todos os direitos reservados</span>
            </address>
        </div>
    </div>
</body>

</html>