<div class="nav_menu">
    <div id="menu_v" class="menu_v">
        <ul>
            <li class="active">
                <a href="#" class="selected"><span>Protocolos</span><span class="i"></span></a>
            </li>

            <li>
                <a href="#"><span>Usuarios</span><span class="i"></span></a>
            </li>
        </ul>
    </div>
</div>