var db = {
   
    "dados": [
        {

         "img": "https://orofacial.com.br/files/2014/08/Slide6_Web.jpg",
         "nome": "xadrez/Sabrina",
         "idade": "26",
         "faculdade": "puc",
         "curso": "direito",
         "cidade": "belo horizonte",
         "genero": "feminino",
         "email": "leonina@gmail.com",
        },

        {

            "img": "https://orofacial.com.br/files/2014/08/Slide6_Web.jpg",
            "nome": "war/Marcos",
            "idade": "19",
            "faculdade": "una",
            "curso": "enfermagem",
            "cidade": "belo horizonte",
            "genero": "masculino",
            "email": "marcolfk@gmail.com",
           },

           {

            "img": "https://orofacial.com.br/files/2014/08/Slide6_Web.jpg",
            "nome": "xadrez/Giulia",
            "idade": "22",
            "faculdade": "pitagoras",
            "curso": "engenharia civil",
            "cidade": "belo horizonte",
            "genero": "feminino",
            "email": "marcilene@gmail.com",
           }

        
        
    ],

    "interesses": [
        {
         
        "int1": [{ 'nome': 'tabulero', 'descrição': '', 'sub-interesses': ['dama','xadrez','war'] }]
        

    }

    ],

    "grupos": [
        {
          "tipos": ['xadrez', 'dama', 'war' ]
        }
    ]
    
}